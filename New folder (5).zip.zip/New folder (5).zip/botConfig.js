module.exports = {
    token: "OTg5MTcyNTYxOTUyNzY4MDUy.G53xAu.yy_ycQFF3cMPntHQaZdfMv59QtgJ29fp13a_gk",
    prefix: ",",
    admins: [
        "857516957502013493"
],
    debug: true,
    countChannel: ""
};
